# SP_ORG — Pacote de Continuidade 0.13-A

Este ZIP é o **Source of Truth portátil** do módulo **Servo Peregrino Organizador — Nexus + Items** em 25/09/2026.

Ele foi montado para permitir quatro cenários sem depender desta conversa:

1. subir o código em Git/GitHub/GitLab;
2. entregar o projeto a outro desenvolvedor;
3. continuar o desenvolvimento com outra IA/chat;
4. reconstruir/validar a última versão do mod e da missão-laboratório.

## Estado em uma frase

**0.12 FINAL está homologada manualmente; 0.13-A implementa autoridade de servidor para a biblioteca pública; a primeira conversão para addon falhou no carregamento dos PBOs e o Packaging R2 foi reempacotado, mas ainda precisa ser validado dentro do Arma antes de iniciar 0.13-B.**

## Leia nesta ordem

1. `docs/00_STATUS_ATUAL.md`
2. `docs/01_ARQUITETURA.md`
3. `docs/02_CONFIGURACAO_INSTALACAO_BUILD.md`
4. `docs/03_API_NEXUS.md`
5. `docs/04_API_ITEMS.md`
6. `docs/05_MODELOS_DE_DADOS_E_CONTRATOS.md`
7. `docs/06_MULTIPLAYER_E_AUTORIDADE_0_13_A.md`
8. `docs/07_TESTES_E_HOMOLOGACAO.md`
9. `docs/08_LICOES_APRENDIDAS_DO_DONT.md`
10. `docs/09_ROADMAP_E_PROXIMO_PASSO.md`
11. `docs/10_CONTINUAR_COM_IA.md`

## Estrutura

- `repo/` — fonte pronto para Git.
- `release/` — última build PBO candidata + missão multiplayer R3.
- `baselines/` — artefatos que preservam as baselines-chave.
- `history/raw_project_docs/` — documentação histórica acumulada da missão 0.13-A.
- `machine/` — índices CSV/JSON para humanos, scripts e IA.
- `evidence/` — RPT e screenshots do problema que levou ao Packaging R2.

## Regra de ouro

**Nunca reconstruir uma entrega a partir de memória quando existe uma baseline.** Toda nova entrega deve partir do artefato/source tree imediatamente anterior, ser tratada como delta pequeno e preservar os contratos congelados, salvo evidência reproduzível de defeito.
